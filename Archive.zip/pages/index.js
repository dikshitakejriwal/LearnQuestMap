import study from './study';

export default study